module Mod_depth ( depth ) where
import Prelude hiding (and, or) 
import Debug.Trace
import Splib
import Types

depth